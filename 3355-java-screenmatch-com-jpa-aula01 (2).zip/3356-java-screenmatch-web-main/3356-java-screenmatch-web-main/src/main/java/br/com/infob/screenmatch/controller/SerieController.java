package br.com.infob.screenmatch.controller;



public class SerieController {
}
